# Load necessary library
library(utils)

# Define the path to the zip file and path to unzip into
zip_file <- "C:\\Users\\HP\\Desktop\\Employee Profile\\Employee Profile.zip"
unzip_dir <- "C:\\Users\\HP\\Desktop\\Employee Profile"

# Unzip the file
unzip(zip_file, exdir = unzip_dir)

# List files in the unzipped directory
files <- list.files(unzip_dir, full.names = TRUE)
print(files)

# Assuming the unzipped file is a CSV, read and display the data
csv_file <- files[grepl("\\.csv$", files)]
if (length(csv_file) > 0) {
  data <- read.csv(csv_file)
  print(head(data))
} else {
  cat("No CSV file found in the unzipped folder.\n")
}


